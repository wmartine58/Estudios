gcc -o thread thread.c  -lpthread
gcc -o once once.c  -lpthread
gcc -o cancel_async cancel_async.c  -lpthread
gcc -o cancel cancel.c  -lpthread
gcc -o hello hello.c  -lpthread
