/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) Daniel Ochoa Donoso 2011 <dochoa@fiec.espol.edu.ec>
 * 
 * main.c is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * main.c is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <math.h> 
#include <stdio.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <unistd.h>
#include <stdlib.h>

 
#define SHMSZ     4 //tamaño de entero
#define NUM_FORKS	5

union semun {
               int val;
               struct semid_ds *buf;
               ushort *array;
          };


int main(int argc, char *argv[])
{
	pid_t pid;
    int  *shm,shmid,total,i,status,k,j;
    key_t key_d,key_s;
	int semid,semflg,nsems,nsops; /* semid of semaphore set */
	struct sembuf *sops; 
	union semun arg;

	if (argc != 2) {
		fprintf(stderr,"usage: a.out <integer value>\n");	
		abort();
	}

	if (atoi(argv[1]) < 0) {
		fprintf(stderr,"Argument %d must be non-negative\n",atoi(argv[1]));	
		abort();
	}

    // Segmento de memoria compartida para datos
	key_d = 1678;
    if ((shmid = shmget(key_d, SHMSZ, IPC_CREAT | 0666)) < 0) {
    	    perror("shmget");
        	abort();
	}
    if ((shm = (int *)shmat(shmid, NULL, 0)) == (int *) -1) {
	        	perror("shmat");
	        	abort();
		    }
	*shm=0;

	//inicializacion de semaforo 
	key_s = 1234; /* key */
	semflg = IPC_CREAT | 0666; /* permisos */
	nsems = 1; /* numero de semaforos */
	nsops = 1; /* numero de operaciones */
	sops = (struct sembuf *) malloc(2*sizeof(struct sembuf)); 

 	if ((semid = semget(key_s, nsems, semflg)) == -1) {
		perror("semget: semget failed");
		abort();
    }
	arg.val=0;
	semctl(semid,0,SETVAL,arg);
	sops[0].sem_num = 0; 
	sops[0].sem_op = 1; 
   	sops[0].sem_flg = SEM_UNDO; 

   	nsops=1;
    if ((j = semop(semid, sops, nsops)) == -1) {
					perror("semop: semop failed");
	} 

	for (k=0;k<NUM_FORKS;k++)
	{
		pid=fork();	
		if (pid==0) //codigo del hijo
		{
			shmid=0;shm=NULL;  //agrego variables compartidas
			if ((shmid = shmget(key_d, SHMSZ, 0666)) < 0) {
     	   		perror("shmget");
        		abort();
    		}
	    	if ((shm = (int *)shmat(shmid, NULL, 0)) == (int *) -1) {
    	    	perror("shmat");
    	    	abort();
    		}
					
			for (i=0;i<atoi(argv[1]);i++)
			{
		    	sops[0].sem_num = 0; 
      			sops[0].sem_op = -1; /* wait for semaphore flag to become zero */
			    sops[0].sem_flg = SEM_UNDO ; /* take off semaphore asynchronous  */
       			sops[1].sem_num = 0;
       			sops[1].sem_op = 0; 
       			sops[1].sem_flg = SEM_UNDO | IPC_NOWAIT;
  
			    nsops=2;
      			if ((j = semop(semid, sops, nsops)) == -1) {
					perror("semop1: semop failed");
				} 
		     
				total=*shm;
				total++;			
				(*shm)=total;

	  		    sops[0].sem_num = 0; 
      			sops[0].sem_op = 1; /* release */
			    sops[0].sem_flg = SEM_UNDO | IPC_NOWAIT; /* take off semaphore asynchronous  */

				nsops=1;
	  			if ((j = semop(semid, sops, nsops)) == -1) {
					perror("semop2: semop failed");
				} 
			}			
			exit(EXIT_SUCCESS);
		}
	}

	while (1) {
	    pid_t done = wait(&status);
	    if (done == -1) {
        if (errno == ECHILD) break; // no more child processes
	    } else {
        if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
            printf("hijo %d terminado\n",done);
    	    }
    	}
	}

	semctl(semid,0,IPC_RMID,0);
	printf("padre total= %d\n",*shm);
	exit(EXIT_SUCCESS);
}
