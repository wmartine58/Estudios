
#ifndef _ELINUX_INTRIN_H_
#define _ELINUX_INTRIN_H_

#include <VP_Os/linux/intrin.h>

#endif // _ELINUX_INTRIN_H_

