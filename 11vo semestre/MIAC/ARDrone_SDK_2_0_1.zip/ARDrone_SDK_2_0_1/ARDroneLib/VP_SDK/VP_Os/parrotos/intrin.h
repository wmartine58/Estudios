
#ifndef _PARROTOS_INTRIN_H_
#define _PARROTOS_INTRIN_H_

#include <VP_Os/elinux/intrin.h>

#endif // ! _PARROTOS_INTRIN_H_

