#ifndef _COMIP_H_
#define _COMIP_H_

int vp_com_config_itf( const char* interface, const char * ip, const char* broadcast, const char* netmask );

#endif // _COMIP_H_
